<?php
/**
 * Skills Section - Static Content
 *
 * @package Abanoub_Portfolio
 */
?>

<section id="about">
    <section class="skills-wrapper-unique">
        
        <div class="section-header">
            <span class="section-header__tag">&lt;</span>
            <h2 class="section-header__title">skills & tools</h2>
            <span class="section-header__tag">/&gt;</span>
        </div>

        <div class="skills-inner-container">

            <ul class="skills-flex-grid">
                
                <!-- 1. HTML -->
                <li class="skill-pill" style="--duration: 7s; --delay: 0.2s; --x-move: 8px; --y-move: -12px;">
                    <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/icons/html.png' ); ?>" alt="HTML">
                    <span>HTML</span>
                </li>
                
                <!-- 2. CSS -->
                <li class="skill-pill" style="--duration: 5s; --delay: 0.5s; --x-move: -6px; --y-move: -15px;">
                    <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/icons/css.png' ); ?>" alt="CSS">
                    <span>CSS</span>
                </li>


                <!-- 4. JavaScript -->
                <li class="skill-pill" style="--duration: 6s; --delay: 0.8s; --x-move: -10px; --y-move: -18px;">
                    <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/icons/javascript.gif' ); ?>" alt="JS">
                    <span>JavaScript</span>
                </li>
                
                
                 <!-- 17. JQuery -->
                <li class="skill-pill" style="--duration: 8s; --delay: 0.4s; --x-move: 5px; --y-move: -11px;">
                    <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/icons/jQuery.png' ); ?>" alt="JQuery">
                    <span>JQuery</span>
                </li>
                
                <!-- 4. TypeScript -->
                <li class="skill-pill" style="--duration: 6s; --delay: 0.8s; --x-move: -10px; --y-move: -18px;">
                    <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/icons/typescript.jpg' ); ?>" alt="TS">
                    <span>TypeScript</span>
                </li>

                <!-- 5. PHP -->
                <li class="skill-pill" style="--duration: 9s; --delay: 0.3s; --x-move: 5px; --y-move: -14px;">
                    <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/icons/php.png' ); ?>" alt="PHP">
                    <span>PHP</span>
                </li>

                 <!-- 17. MySQL -->
                <li class="skill-pill" style="--duration: 8s; --delay: 0.4s; --x-move: 5px; --y-move: -11px;">
                    <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/icons/MySQL.png' ); ?>" alt="MySQL">
                    <span>MySQL</span>
                </li> 
                
                
                <!-- 10. React -->
                <li class="skill-pill" style="--duration: 10s; --delay: 0.2s; --x-move: -9px; --y-move: -10px;">
                    <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/icons/react.png' ); ?>" alt="React">
                    <span>React</span>
                </li>

                <!-- 11. Bootstrap -->
                <li class="skill-pill" style="--duration: 4.5s; --delay: 1s; --x-move: 6px; --y-move: -18px;">
                    <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/icons/bootstrap.png' ); ?>" alt="Bootstrap">
                    <span>Bootstrap</span>
                </li>

                <!-- 12. Tailwind -->
                <li class="skill-pill" style="--duration: 7.8s; --delay: 0.5s; --x-move: -12px; --y-move: -14px;">
                    <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/icons/tailwind.png' ); ?>" alt="Tailwind">
                    <span>Tailwind</span>
                </li>

            
                
                <!-- 13. Github -->
                <li class="skill-pill" style="--duration: 9.2s; --delay: 0.1s; --x-move: 9px; --y-move: -12px;">
                    <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/icons/github.png' ); ?>" alt="Github">
                    <span>Github</span>
                </li>
                
                <!-- 13. Git -->
                <li class="skill-pill" style="--duration: 9.2s; --delay: 0.1s; --x-move: 9px; --y-move: -12px;">
                    <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/icons/git.png' ); ?>" alt="Git">
                    <span>Git</span>
                </li>


                <!-- 3. WordPress -->
                <li class="skill-pill" style="--duration: 8s; --delay: 0.1s; --x-move: 10px; --y-move: -8px;">
                    <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/icons/wp.png' ); ?>" alt="WordPress">
                    <span>WordPress</span>
                </li>
                
                
                <!-- 7. Elementor -->
                <li class="skill-pill" style="--duration: 5.5s; --delay: 0.9s; --x-move: 12px; --y-move: -20px;">
                    <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/icons/elementor.png' ); ?>" alt="Elementor">
                    <span>Elementor</span>
                </li>
                
                
                <!-- 7. Gutenberg -->
                <li class="skill-pill" style="--duration: 5.5s; --delay: 0.9s; --x-move: 12px; --y-move: -20px;">
                    <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/icons/Gutenberg.png' ); ?>" alt="Gutenberg">
                    <span>Gutenberg</span>
                </li>
                
                <!-- 7. Wp-Bakery -->
                <li class="skill-pill" style="--duration: 5.5s; --delay: 0.9s; --x-move: 12px; --y-move: -20px;">
                    <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/icons/WpBakery.png' ); ?>" alt="WpBakery">
                    <span>WpBakery</span>
                </li>

                <!-- 8. WooCommerce -->
                <li class="skill-pill" style="--duration: 8.5s; --delay: 0.4s; --x-move: -5px; --y-move: -12px;">
                    <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/icons/WooCommerce.png' ); ?>" alt="Woo">
                    <span>WooCommerce</span>
                </li>

                <!-- 9. Shopify -->
                <li class="skill-pill" style="--duration: 6.5s; --delay: 0.7s; --x-move: 7px; --y-move: -16px;">
                    <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/icons/shopify.png' ); ?>" alt="Shopify">
                    <span>Shopify</span>
                </li>

                <!-- 9. Salla -->
                <li class="skill-pill" style="--duration: 6.5s; --delay: 0.7s; --x-move: 7px; --y-move: -16px;">
                    <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/icons/Salla.png' ); ?>" alt="Salla">
                    <span>Salla</span>
                </li>

                <!-- 9. EasyOrder -->
                <li class="skill-pill" style="--duration: 6.5s; --delay: 0.7s; --x-move: 7px; --y-move: -16px;">
                    <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/icons/EasyOrder.png' ); ?>" alt="EasyOrder">
                    <span>EasyOrder</span>
                </li>

                <!-- 14. SEO -->
                <li class="skill-pill" style="--duration: 6.8s; --delay: 0.8s; --x-move: -7px; --y-move: -15px;">
                    <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/icons/seo.png' ); ?>" alt="SEO">
                    <span>SEO</span>
                </li>

                <!-- 16. Figma -->
                <li class="skill-pill" style="--duration: 8s; --delay: 0.4s; --x-move: 5px; --y-move: -11px;">
                    <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/icons/figma.png' ); ?>" alt="Figma">
                    <span>Figma</span>
                </li>
                
                 <!-- 16. Canva -->
                <li class="skill-pill" style="--duration: 8s; --delay: 0.4s; --x-move: 5px; --y-move: -11px;">
                    <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/icons/canva.png' ); ?>" alt="canva">
                    <span>Canva</span>
                </li>

            </ul>

            <div class="skills-cta-area">
                <p><?php esc_html_e( "You've Got A Challenge?", 'abanoub-portfolio' ); ?> <a href="#contact"><?php esc_html_e( "Let's Talk!", 'abanoub-portfolio' ); ?></a></p>
            </div>
        </div>
    </section>
</section>