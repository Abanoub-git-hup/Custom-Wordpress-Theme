<?php
/**
 * Resume Section - Clean Coding Style
 *
 * @package Abanoub_Portfolio
 */
?>

<section id="Resume">
    <div class="section-header">
        <span class="section-header__tag">&lt;</span>
        <h2 class="section-header__title">resume</h2>
        <span class="section-header__tag">/&gt;</span>
    </div>

    <section class="resume-section" id="resume-content">
        <div class="container">
            <div class="resume-centered-container">
                
                <div class="resume-block">
                    <h3 class="resume-title"><i class="fa-solid fa-briefcase"></i> <?php esc_html_e( 'Professional Experience', 'abanoub-portfolio' ); ?></h3>
                    <div class="timeline">
                        <div class="timeline-item">
                            <div class="timeline-dot"></div>
                            <h4 class="item-title"><?php esc_html_e( 'WordPress Developer', 'abanoub-portfolio' ); ?></h4>
                            <span class="item-date"><?php esc_html_e( '2024 - Present', 'abanoub-portfolio' ); ?></span>
                            <ul class="item-details">
                                <li><?php esc_html_e( 'Freelancer Upwork - Fiverr', 'abanoub-portfolio' ); ?></li>
                            </ul>
                        </div>
                        
                        <div class="timeline-item">
                            <div class="timeline-dot"></div>
                            <h4 class="item-title"><?php esc_html_e( 'Front-End Developer', 'abanoub-portfolio' ); ?></h4>
                            <span class="item-date"><?php esc_html_e( '2025 - Present', 'abanoub-portfolio' ); ?></span>
                        </div>
                    </div>
                </div>

                <div class="resume-block">
                    <h3 class="resume-title"><i class="fa-solid fa-graduation-cap"></i> <?php esc_html_e( 'Education', 'abanoub-portfolio' ); ?></h3>
                    <div class="timeline">
                        <div class="timeline-item">
                            <div class="timeline-dot"></div>
                            <h4 class="item-title"><?php esc_html_e( 'Bachelor’s Degree in Business', 'abanoub-portfolio' ); ?></h4>
                            <span class="item-date"><?php esc_html_e( '2022 - 2026', 'abanoub-portfolio' ); ?></span>
                            <p class="item-company"><?php esc_html_e( 'Ain Shams University - Cairo', 'abanoub-portfolio' ); ?></p>
                        </div>
                    </div>
                </div>

                <div class="resume-block">
                    <h3 class="resume-title"><i class="fa-solid fa-medal"></i> <?php esc_html_e( 'Certifications', 'abanoub-portfolio' ); ?></h3>
                    <div class="cert-grid">
                        <div class="cert-card">
                            <span class="cert-date">2024</span>
                            <h4><?php esc_html_e( 'WordPress Development – Udemy', 'abanoub-portfolio' ); ?></h4>
                        </div>
                        <div class="cert-card">
                            <span class="cert-date">2025</span>
                            <h4><?php esc_html_e( 'PHP & MySQL Fundamentals – Coursera', 'abanoub-portfolio' ); ?></h4>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
</section>