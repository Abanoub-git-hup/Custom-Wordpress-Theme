<?php
/**
 * Contact Section
 *
 * @package Abanoub_Portfolio
 */
?>

<section id="contact">
    <div class="container">
        <div class="contact-wrapper">
            
            <div class="contact-info">
                <div class="section-badge">
                    <span class="line"></span>
                    <span class="badge-text"><?php esc_html_e( 'Contact Me', 'abanoub-portfolio' ); ?></span>
                </div>
                <h2 class="section-title"><?php esc_html_e( 'Get In Touch With Me', 'abanoub-portfolio' ); ?></h2>
                <p class="section-description">
                    <?php esc_html_e( 'The technological revolution is changing aspect of our lives, and the fabric of society itself. it\'s also changing the way we learn and what we learn.', 'abanoub-portfolio' ); ?>
                </p>

                <div class="contact-details">
                    <div class="detail-item">
                        <div class="icon-box">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
                        </div>
                        <div class="detail-text">
                            <h3><?php esc_html_e( 'Phone', 'abanoub-portfolio' ); ?></h3>
                            <p><?php echo esc_html( get_theme_mod( 'social_whatsapp', '+201127515638' ) ); ?></p>
                        </div>
                    </div>

                    <div class="detail-item">
                        <div class="icon-box">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
                        </div>
                        <div class="detail-text">
                            <h3><?php esc_html_e( 'Email', 'abanoub-portfolio' ); ?></h3>
                            <p><?php echo esc_html( get_theme_mod( 'social_email', 'abanoubmorise3200@gmail.com' ) ); ?></p>
                        </div>
                    </div>
                </div>
            </div>

           <div class="contact-form-container">
    <form class="contact-form" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>" method="post">
        
        <input type="hidden" name="action" value="abanoub_contact_form">

        <div class="form-row">
            <div class="input-group">
                <input type="text" id="name" name="full_name" placeholder="<?php esc_attr_e( 'Full Name', 'abanoub-portfolio' ); ?>" required aria-label="<?php esc_attr_e( 'Full Name', 'abanoub-portfolio' ); ?>">
            </div>
            <div class="input-group">
                <input type="email" id="email" name="email" placeholder="<?php esc_attr_e( 'Email', 'abanoub-portfolio' ); ?>" required aria-label="<?php esc_attr_e( 'Email', 'abanoub-portfolio' ); ?>">
            </div>
        </div>
        <div class="input-group">
            <textarea id="message" name="message" rows="8" placeholder="<?php esc_attr_e( 'Message', 'abanoub-portfolio' ); ?>" required aria-label="<?php esc_attr_e( 'Message', 'abanoub-portfolio' ); ?>"></textarea>
        </div>
        <button type="submit" class="submit-btn"><?php esc_html_e( 'Message', 'abanoub-portfolio' ); ?></button>
    </form>
</div>

        </div>
    </div>

    <!-- Work Together Call to Action -->
    <section class="work-together" aria-label="<?php esc_attr_e( 'Contact Section', 'abanoub-portfolio' ); ?>">
        <div class="floating-assets">
           
            <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/icons/shopify.png' ); ?>" alt="Shopify" class="icon icon-react">
            <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/icons/WooCommerce.png' ); ?>" alt="Woo " class="icon icon-html">
            <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/icons/wp.png' ); ?>" alt="WordPress" class="icon icon-wp">
            <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/icons/figma.png' ); ?>"  alt="Figma" class="icon icon-figma">
            <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/icons/bootstrap.png' ); ?>" alt="Bootstrap" class="icon icon-bootstrap">
            <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/icons/elementor.png' ); ?>" alt="Elementor" class="icon icon-elementor">
            
        </div>
        <div class="container">
            <div class="content-wrapper">
                <h2 class="main-heading">
                    <?php echo esc_html_e( "LET'S WORK", 'abanoub-portfolio' ); ?> <br> <?php echo esc_html_e( 'TOGETHER', 'abanoub-portfolio' ); ?>
                </h2>

                <a href="<?php echo esc_url( get_theme_mod( 'social_whatsapp', '#' ) ); ?>" class="cta-circle" target="_blank" aria-label="<?php esc_attr_e( 'Get In Touch', 'abanoub-portfolio' ); ?>">
                    <div class="cta-content">
                        <span class="arrow">↗</span>
                        <span class="cta-text"><?php esc_html_e( 'Get In Touch', 'abanoub-portfolio' ); ?></span>
                    </div>
                </a>
            </div>
             <a href="https://wa.me/201127515638" class="whatsapp-btn" target="_blank" aria-label="Chat on WhatsApp">
             <i class="fa-brands fa-whatsapp"></i>
             <span class="tooltip">Chat with me!</span>
             </a>
            </div>
        
    </section>
</section>