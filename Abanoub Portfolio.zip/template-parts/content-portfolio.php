<?php echo do_shortcode('[display_portfolio]'); ?>


