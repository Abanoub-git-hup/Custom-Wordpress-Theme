<?php

/**

 * Hero Section - Professional English Version

 *

 * @package Abanoub_Portfolio

 */

?>



<section id="home">

    <main class="hero container">

        <section class="hero-content">

            <span class="hero-welcome">

                <?php echo esc_html( get_theme_mod( 'hero_welcome', 'HI I AM' ) ); ?>

            </span>



            <h1 class="hero-title">

                <?php echo esc_html( get_theme_mod( 'hero_name', 'Abanoub' ) ); ?> 


                <span class="accent-text"><?php echo esc_html( get_theme_mod( 'hero_lastname', 'Maurice' ) ); ?></span>

            </h1>



            <h2 class="hero-subtitle">

                <?php esc_html_e( 'Specialized ', 'abanoub-portfolio' ); ?> 

                <br>

                <span id="dynamic-text" class="accent-text"><?php esc_html_e( 'Digital Experiences', 'abanoub-portfolio' ); ?></span>

            </h2>



            <p class="hero-description">

                <?php 

                $default_desc = 'A front-end developer and WordPress expert, I pay attention to minute details and smooth animation to create an unforgettable visual identity for your next project.';

                echo esc_html( get_theme_mod( 'hero_description', $default_desc ) ); 

                ?>

            </p>



            <div class="hero-btns">

                <a href="#contact" class="btn btn-primary">

                    <?php esc_html_e( 'Start a Project', 'abanoub-portfolio' ); ?>

                </a>

                <a href="#portfolio" class="btn btn-outline">

                    <?php esc_html_e( 'My Portfolio', 'abanoub-portfolio' ); ?>

                </a>

            </div>

        </section>



        <section class="hero-visual">

            <div class="image-wrapper">

                <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/profile.png' ); ?>" 

                     alt="<?php esc_attr_e( 'Abanoub Maurice - WordPress Developer', 'abanoub-portfolio' ); ?>" 

                     class="profile-img">

                

                <div class="floating-card design">

                    <i class="fa-solid fa-wand-sparkles"></i>

                    <span><?php esc_html_e( 'Design', 'abanoub-portfolio' ); ?></span>

                </div>

                <div class="floating-card ideas">

                    <i class="fa-solid fa-bolt-lightning"></i>

                    <span><?php esc_html_e( 'Ideas', 'abanoub-portfolio' ); ?></span>

                </div>

                <div class="floating-card code">

                    <i class="fa-solid fa-code"></i>

                    <span><?php esc_html_e( 'Code', 'abanoub-portfolio' ); ?></span>

                </div>

            </div>

        </section>

    </main>

</section>